# Qwen3.5-4B track: prompts and context-window management

Pair: Ashutosh Saxena (24BCS041) and Masabathini Saketh (24BCS147).
Assignment 6: Phase 1 (6a) and Phase 2 (6b) of the ELM module, both done with the local model Qwen3.5-4B.

## 1. Setup

| Item | Value |
|---|---|
| Model | Qwen3.5-4B (Alibaba Qwen), Q4_K_M GGUF (unsloth build), sha256 00fe7986... |
| Runtime | llama.cpp b11560, Metal, `llama-server` |
| Coding agent | Pi coding agent (non-interactive JSON mode) |
| Hardware | MacBook Air M2, 8 GB unified memory, macOS 27.0 |
| Base | Fusion-Integrated `main` at 02b01fe |
| Phase 1 branch | elm-6a-qwen35-24BCS041-24BCS147 |
| Phase 2 branch | elm-6b-qwen35-24BCS041-24BCS147 (made from the Phase 1 branch) |

Server flags in both phases: `-c 32768 -ngl 999 -fa on -ctk q8_0 -ctv q8_0 --cache-ram 0 -ctxcp 8 --jinja`.
Sampling: temperature 0.6, top-p 0.95, top-k 20, min-p 0.

## 2. How the context window was managed

The model has a 32,768-token window on this machine.
The must-read material (ELM spec about 75k tokens, reference module about 155k tokens) is far larger.
These measures kept each request inside the window and kept the Mac from running out of memory.

**Phase 1 (12 Oct, one 3-hour session).**

1. The six spec files were exported to plain text and split into 62 small numbered parts, so the model could read one part at a time instead of a whole document.
2. The prompt named the reference modules and the check command, so the model did not have to search for them.
3. Pi's automatic compaction summarized the conversation when the window filled. It ran 16 times.
4. The context cache used q8_0 (half the memory of f16). The server's RAM prompt cache was off (`--cache-ram 0`) and only 8 context checkpoints were kept, because the default 8 GiB cache filled swap and the boot disk on this 8 GB Mac.
5. A watchdog stopped the run when free memory or free disk fell below a floor.

Measured: 487,140 prompt tokens read at 121 tokens/s, 57,174 tokens generated at 8.5 tokens/s.

**Phase 2 (26 Oct, one 15-minute session).**

1. A fresh session with one concrete goal and named files, instead of continuing the long Phase 1 conversation.
2. An appended guide of under 1k tokens with a read budget: never print whole files, read with offset and limit, write output early.
3. A Pi extension cut every tool result to 4,000 characters with a pointer to read further in slices, so one large file could not fill the window.
4. A fast check script (`quick-check.sh`) replaced the full `make check` inside the session; the full suite would spend minutes per run.
5. The run was capped at 15 minutes.

Measured: 15,698 prompt tokens read at 102 tokens/s, 5,327 tokens generated at 8.2 tokens/s, peak context use well below the window, no compaction needed.

## 3. Results

| | Phase 1 | Phase 2 |
|---|---|---|
| Files | 16 new files under modules/leave (2,507 lines) | 14 files changed (229 added, 261 removed) |
| Lint errors (ruff) | 316 | 95 |
| Wired into settings/URLs | No | No (session ended at its time cap before this step) |
| Tool calls / failed calls | not counted | 37 / 12 (mostly lint commands that exit non-zero) |
| Stop reason | 3-hour limit | 15-minute limit |

## 4. Prompts used (exact text, extracted from the Pi session files)

### 4.1 Phase 1

## System prompt (as sent)

```
You are an expert coding assistant operating inside pi, a coding agent harness. You help users by reading files, executing commands, editing code, and writing new files.

<tools>
- read: Read file contents
- bash: Execute bash commands (ls, grep, find, etc.)
- edit: Make precise file edits with exact text replacement, including multiple disjoint edits in one call
- write: Create or overwrite files

In addition to the tools above, you may have access to other custom tools depending on the project.
</tools>

<rules>
- Use bash for file operations like ls, rg, find
- Use read to examine files instead of cat or sed.
- You can inspect PI_* environment variables for current model and session details.
- Use edit for precise changes (edits[].oldText must match exactly)
- When changing multiple separate locations in one file, use one edit call with multiple entries in edits[] instead of multiple edit calls
- Each edits[].oldText is matched against the original file, not after earlier edits are applied. Do not emit overlapping or nested edits. Merge nearby changes into one edit.
- Keep edits[].oldText as small as possible while still being unique in the file. Do not pad with large unchanged regions.
- Use write only for new files or complete rewrites.
- Be concise in your responses
- Show file paths clearly when working with files
</rules>

<docs>
Pi documentation (read only when the user asks about pi itself, its SDK, extensions, themes, skills, or TUI):
- Main documentation: /Users/ashutoshsaxena/.local/lib/node_modules/@earendil-works/pi-coding-agent/README.md
- Additional docs: /Users/ashutoshsaxena/.local/lib/node_modules/@earendil-works/pi-coding-agent/docs
- Examples: /Users/ashutoshsaxena/.local/lib/node_modules/@earendil-works/pi-coding-agent/examples (extensions, custom tools, SDK)
- When reading pi docs or examples, resolve docs/... under Additional docs and examples/... under Examples, not the current working directory
- When asked about: extensions (docs/extensions.md, examples/extensions/), themes (docs/themes.md), skills (docs/skills.md), prompt templates (docs/prompt-templates.md), TUI components (docs/tui.md), keybindings (docs/keybindings.md), SDK integrations (docs/sdk.md), custom providers (docs/custom-provider.md), adding models (docs/models.md), pi packages (docs/packages.md), environment variables (docs/environment-variables.md), MCP servers (docs/mcp.md), codemode scripts and non-LLM models such as classifiers and image models (docs/codemode.md)
- When working on pi topics, read the docs and examples, and follow .md cross-references before implementing
- Always read pi .md files completely and follow links to related docs (e.g., tui.md for TUI API details)
</docs>

<cwd>
/Volumes/T7-Tools/fusion-qwen-elm/Fusion-Integrated
</cwd>
```

## User prompt (as sent)

```
Inspect the provided Fusion ERP base repository (the current directory) and the supplied Employee Leave Management (ELM) specification artifacts in /Volumes/T7-Tools/fusion-qwen-elm/elm_specs/ (plain-text exports split into small numbered parts: 01 Problem Statement, 02 Functional Requirement Specification, 03 Use Case Specifications, 04 Business Rule Specifications, 06 Workflow Specifications, 06 Traceability Matrix; read the parts you need, one at a time).
Implement the ELM module as an integrated module of the existing Fusion ERP system.
Reuse the authentication/login, role-management mechanism, common UI/layout/navigation, backend structure, database configuration, shared components, and other common functionality already available in the Fusion Base Code.
Do not unnecessarily rebuild or replace common functionality already present in Fusion.
Implement the required ELM frontend and backend functionality, including appropriate data models, services, APIs/routes, UI components/pages, role-dependent behavior, database changes, and integration with the existing Fusion structure.
First understand the existing repository and the supplied specifications, and then make the necessary repository-level changes.
Start with README.md, docs/08-delivery/role-assignment-guide.md, and modules/placement and modules/directory as the reference module shape; the backend venv is .venv and 'make check' runs CI.
Attempt to build/run or otherwise verify the resulting implementation where possible.
```

### 4.2 Phase 2

## System prompt (as sent)

```
You are an expert coding assistant operating inside pi, a coding agent harness. You help users by reading files, executing commands, editing code, and writing new files.

<tools>
- read: Read file contents
- bash: Execute bash commands (ls, grep, find, etc.)
- edit: Make precise file edits with exact text replacement, including multiple disjoint edits in one call
- write: Create or overwrite files

In addition to the tools above, you may have access to other custom tools depending on the project.
</tools>

<rules>
- Use bash for file operations like ls, rg, find
- Use read to examine files instead of cat or sed.
- You can inspect PI_* environment variables for current model and session details.
- Use edit for precise changes (edits[].oldText must match exactly)
- When changing multiple separate locations in one file, use one edit call with multiple entries in edits[] instead of multiple edit calls
- Each edits[].oldText is matched against the original file, not after earlier edits are applied. Do not emit overlapping or nested edits. Merge nearby changes into one edit.
- Keep edits[].oldText as small as possible while still being unique in the file. Do not pad with large unchanged regions.
- Use write only for new files or complete rewrites.
- Be concise in your responses
- Show file paths clearly when working with files
</rules>

<docs>
Pi documentation (read only when the user asks about pi itself, its SDK, extensions, themes, skills, or TUI):
- Main documentation: /Users/ashutoshsaxena/.local/lib/node_modules/@earendil-works/pi-coding-agent/README.md
- Additional docs: /Users/ashutoshsaxena/.local/lib/node_modules/@earendil-works/pi-coding-agent/docs
- Examples: /Users/ashutoshsaxena/.local/lib/node_modules/@earendil-works/pi-coding-agent/examples (extensions, custom tools, SDK)
- When reading pi docs or examples, resolve docs/... under Additional docs and examples/... under Examples, not the current working directory
- When asked about: extensions (docs/extensions.md, examples/extensions/), themes (docs/themes.md), skills (docs/skills.md), prompt templates (docs/prompt-templates.md), TUI components (docs/tui.md), keybindings (docs/keybindings.md), SDK integrations (docs/sdk.md), custom providers (docs/custom-provider.md), adding models (docs/models.md), pi packages (docs/packages.md), environment variables (docs/environment-variables.md), MCP servers (docs/mcp.md), codemode scripts and non-LLM models such as classifiers and image models (docs/codemode.md)
- When working on pi topics, read the docs and examples, and follow .md cross-references before implementing
- Always read pi .md files completely and follow links to related docs (e.g., tui.md for TUI API details)
</docs>

<addendum>
# How to work in this repository (Fusion-Integrated: Django + DRF backend, React + TypeScript client)

You are building the Employee Leave Management (ELM) module, code `leave`, inside this repository.
You work in short sessions. Each session has one goal, given in the user message.
Notes that must survive between sessions live in docs/09-leave/leave-blueprint.md. Read it first (except in the session that writes it).

## Workflow
1. Read only what the goal needs: the blueprint, the reference files the goal names, and spec ids via grep.
   The ELM specification is plain text in ~/a6/spec (index: ~/a6/spec/elm-index.md).
   Example: grep -n -A12 "^BR-EL-002 " ~/a6/spec/04_business_rules.txt
2. Write down the list of files you will create or change, then work one file at a time.
3. After each new Python file run: .venv/bin/python manage.py check 2>&1 | tail -5
4. Before finishing run: sh ~/a6/orch/quick-check.sh
   Fix the FIRST failure it prints, then run it again. Repeat until it prints ALL OK. Never stop while it fails.
5. Final answer: list the files you created or changed.

## Repository rules
- Copy the shape of modules/placement (apps.py, registry.py, contracts.py, domain/, models/, selectors/, services/, api/, tests/). Do not invent a new structure.
- modules/leave/domain is pure Python: never import django, rest_framework or celery there.
- No ForeignKey to another module or to a user table. A person is a plain integer user_id field.
- Every API view sets permission_classes = [HasModuleGrant("leave"), HasPermission("leave.<noun>.<verb>")] from fusion_auth.permissions.
- Generated files are never edited by hand: after a registry.py change run make permissions; after an API change run make schema.
- contracts.py getters take a list of ids and have plural names (get_leave_balances(user_ids)).
- Comments are one line and only where the reason is not obvious. No AI attribution anywhere.
- Never cite retired ids: EL-UC-006, BR-EL-021, BR-EL-026.
- Stay inside this repository. Do not delete or rewrite existing tests or checks to make them pass.

## Context budget (your context is small)
- Never cat a whole file. Use the read tool with offset and limit (for example limit 80), or grep -n PATTERN FILE | head -40.
- Read only the files the goal names. Stop reading as soon as you can do the goal.
- Write the output file early, then improve it. A finished file beats a perfect plan in your head.

## Tool use
- read before edit. Keep edit replacements small and exact. Use write for new files.
- Keep command output short (| tail -30). Keep your thinking brief: act, then check the result.

</addendum>

<cwd>
/Users/ashutoshsaxena/a6/impl-qwen35
</cwd>
```

## User prompt (as sent)

```
Phase 2 of the ELM assignment: review, test and improve the existing module modules/leave, which you wrote in Phase 1. Do not start a new module and do not delete it.

Do these steps in order.
1. Run .venv/bin/ruff check --fix modules/leave 2>&1 | tail -5. Then run .venv/bin/ruff check modules/leave --statistics to see what is left. Fix the remaining errors file by file: read the failing lines with the read tool (offset and limit), make a small edit, run ruff on that file again.
2. Wire the module into the platform: add "modules.leave" to DOMAIN_MODULES in config/settings/base.py, and add path("api/v1/leave/", include("modules.leave.api.urls")) next to the placement line in config/urls.py.
3. Run .venv/bin/python manage.py check 2>&1 | tail -20. Fix the first error it reports inside modules/leave, then run it again. Repeat until it prints "System check identified no issues".

Final answer: list the files you changed and every problem you found in the Phase 1 code.

```

### 4.3 Output cap extension used in Phase 2

```typescript
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

// A 4B model at 24k context fills its window by printing whole files; cap what each tool call returns.
const MAX_CHARS = 4000;

export default function (pi: ExtensionAPI) {
	pi.on("tool_result", async (event) => {
		const text = event.content.filter((c) => c.type === "text").map((c) => c.text).join("\n");
		if (text.length <= MAX_CHARS) return;
		const head = text.slice(0, MAX_CHARS);
		const note = `\n[output cut at ${MAX_CHARS} of ${text.length} characters. Read the rest with the read tool (offset and limit) or grep -n PATTERN FILE | head -40]`;
		return { content: [{ type: "text", text: head + note }], structuredContent: undefined };
	});
}
```

### 4.4 Fast check script the agent ran in Phase 2

```sh
#!/bin/sh
# Fast repository gates for the agent; prints the first failure and stops.
export DJANGO_SETTINGS_MODULE=config.settings.dev
PY=.venv/bin/python
run() { name="$1"; shift; out=$("$@" 2>&1); rc=$?; if [ $rc -ne 0 ]; then echo "FAILED: $name"; echo "$out" | tail -30; exit 1; fi; echo "ok: $name"; }
run "django check" $PY manage.py check
run "migrations in sync" $PY manage.py makemigrations --check --dry-run
run "ruff" .venv/bin/ruff check .
run "import contracts (lint-imports)" .venv/bin/lint-imports
run "no cross-module foreign keys" $PY ops/checks/no_cross_module_fk.py
run "contract getters plural" $PY ops/checks/contracts_are_plural.py
run "sidebar matches client routes" $PY ops/checks/nav_matches_routes.py
run "permission manifest current (run: make permissions)" $PY manage.py permission_manifest --check
run "openapi schema current (run: make schema)" sh -c "$PY manage.py spectacular --fail-on-warn --file /tmp/leave-schema.yaml >/dev/null && diff -q openapi/fusion-integrated.v1.yaml /tmp/leave-schema.yaml"
for d in modules/leave*/tests; do [ -d "$d" ] && run "module tests ($d)" $PY -m pytest -q -x -p no:cacheprovider "$d"; done
echo "ALL OK"
```

## 5. Notes

The prompts and the run harness were prepared by the pair with help from Claude Code acting as orchestrator.
The orchestrator chose prompts, context limits and checks.
It wrote no module code; all code in this bundle was generated by Qwen3.5-4B.
